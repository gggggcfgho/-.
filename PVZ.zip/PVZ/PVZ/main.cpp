#include"Game.h"

int main() {
	Game myGame;	
	myGame.init();
	myGame.loop();	
}
